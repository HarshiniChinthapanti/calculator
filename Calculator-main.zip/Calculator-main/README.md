<h1 align="center">Hi 👋, I'm Likhitha Gudla</h1>
<h3 align="center">A passionate frontend developer from India</h3>

- I’m currently working on **Basic & Advance Calculator**

- I’m currently learning **DSA, JAVA and working on Internships**

- Ask me about **Html,CSS,JS And Python**

-  How to reach me **likhithagudla7@gmail.com**
<p> Implementing the functionality of the calculator, including defining the mathematical operations, adding error handling mechanism, and implementing advanced functions like logarithm and trigonometry.In this project I am included two types one is basic and other is Scientific calculator. 
I have included in basic calculator with some mathematical operations like addition,substraction,division,multiplication and clear function.
On this I have Included scientific calculator which includes trigonometry functions,algorithmic expressions.
Debugging and testing the code to ensure that it works correctly and is free of bugs and errors.>
</p>


